# Moodle Hyperlink Maintenance Directory - Experiment 01

This document centralizes all internal and external hyperlinks used in the Moodle book for Experiment 01. 
Update this list whenever IDs or external simulation links change.

## 🛠️ Global Equipment Links (DMM & Power Supply)
These links appear in almost every document. They point to the core equipment guide in the Moodle book.

*   **URL:** `mod/book/view.php?id=1212809&chapterid=142`
*   **Target:** Chapter: Equipment Guide (DMM, Power Supply)
*   **Terms linked to this URL:**
    *   `רב-מודד`
    *   `DMM`
    *   `ספק כוח`
    *   `DC Power Supply`

## 🔗 Internal Navigation Links
Links that connect different pages within the Experiment 01 module.

| Target File | Link Text | Current href | Location |
| :--- | :--- | :--- | :--- |
| `00_Intro.html` | חזרה למבוא לניסוי | `../00_Intro.html` | PreLab/PostLab Index |
| `01_PreLab/index.html` | חזרה לתוכן העניינים | `index.html` | PreLab Chapters |
| `02_InLab/index.html` | חזרה לתוכן העניינים | `index.html` | InLab Chapters |
| `PreLab_Exp01_00_Safety.html` | בטיחות ונהלים במעבדה | `PreLab_Exp01_00_Safety.html` | PreLab Index |
| `PreLab_Exp01_01_ColorCode.html` | נגדים וקוד צבעים | `PreLab_Exp01_01_ColorCode.html` | PreLab Index |
| `PreLab_Exp01_02_Equipment.html` | הכרת מכשירי המדידה | `PreLab_Exp01_02_Equipment.html` | PreLab Index |
| `PreLab_Exp01_03_Breadboard.html` | המטריצה (Breadboard) | `PreLab_Exp01_03_Breadboard.html` | PreLab Index |
| `PreLab_Exp01_04_Tinkercad.html` | התנסות וירטואלית (Tinkercad) | `PreLab_Exp01_04_Tinkercad.html` | PreLab Index |

## 🌐 External Links & Simulations
Links pointing to external tools or simulations.

| Platform | Link Text | Current URL | Location |
| :--- | :--- | :--- | :--- |
| **Tinkercad** | לחצו כאן לפתיחת הסימולציה ב-Tinkercad | `https://www.tinkercad.com/things/YOUR_TINKERCAD_ID` | `PreLab_Exp01_04_Tinkercad.html` |
| **Moodle Quiz** | 📝 לחצו כאן למעבר לחידון ההכנה במודל | `INSERT_MOODLE_QUIZ_URL_HERE` | `01_PreLab/index.html` |

---
*Last Updated: June 5, 2026*
